/**
 * copilot-api.ts
 *
 * Drop-in replacement for copilot-cli.ts that calls the GitHub Copilot REST API
 * directly — no local CLI binary required. Works in Docker / remote deployments.
 *
 * Token resolution order:
 *   1. Explicit `githubToken` argument (passed from request header `x-github-pat`)
 *   2. `GITHUB_TOKEN` environment variable (set in Docker / CI)
 *   3. `gh auth token` CLI fallback (local dev only)
 */

import { execSync } from 'child_process';

const COPILOT_API_BASE = 'https://api.githubcopilot.com';
const COPILOT_INTEGRATION_ID = 'vscode-chat';
const DEFAULT_MODEL = 'claude-sonnet-4.5';

function resolveGitHubToken(explicit?: string): string {
  // 1. Explicit token from caller
  if (explicit && explicit.trim()) return explicit.trim();

  // 2. Environment variable (Docker / server deployment)
  if (process.env.GITHUB_TOKEN?.trim()) return process.env.GITHUB_TOKEN.trim();

  // 3. gh CLI fallback (local dev)
  try {
    const token = execSync('gh auth token', { encoding: 'utf-8', timeout: 5000 }).trim();
    if (token) return token;
  } catch {
    // gh not available — fall through to error
  }

  throw new Error(
    'No GitHub token available. Please set your GitHub PAT in Settings, ' +
    'or set the GITHUB_TOKEN environment variable, ' +
    'or run: gh auth login'
  );
}

/**
 * Call the GitHub Copilot chat completions API with a plain text prompt.
 * Returns the assistant's response as a plain string.
 *
 * @param prompt      The user prompt to send
 * @param githubToken Optional GitHub PAT (from Settings / request header)
 * @param model       Model ID (defaults to claude-sonnet-4.5)
 */
export async function runCopilotPrompt(
  prompt: string,
  githubToken?: string,
  model: string = DEFAULT_MODEL
): Promise<string> {
  const token = resolveGitHubToken(githubToken);

  const response = await fetch(`${COPILOT_API_BASE}/chat/completions`, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${token}`,
      'Copilot-Integration-Id': COPILOT_INTEGRATION_ID,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      model,
      max_tokens: 4096,
      temperature: 0.3,
      messages: [{ role: 'user', content: prompt }],
    }),
  });

  if (!response.ok) {
    const text = await response.text();
    throw new Error(`GitHub Copilot API error ${response.status}: ${text.slice(0, 400)}`);
  }

  const json = await response.json();
  const content = json?.choices?.[0]?.message?.content as string | undefined;
  if (!content) {
    throw new Error(`Unexpected Copilot API response: ${JSON.stringify(json).slice(0, 300)}`);
  }
  return content.trim();
}

/**
 * Same as runCopilotPrompt but with a separate system prompt.
 */
export async function runCopilotChat(
  systemPrompt: string,
  userMessage: string,
  githubToken?: string,
  model: string = DEFAULT_MODEL
): Promise<string> {
  const token = resolveGitHubToken(githubToken);

  const response = await fetch(`${COPILOT_API_BASE}/chat/completions`, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${token}`,
      'Copilot-Integration-Id': COPILOT_INTEGRATION_ID,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      model,
      max_tokens: 8192,
      temperature: 0.2,
      messages: [
        { role: 'system', content: systemPrompt },
        { role: 'user', content: userMessage },
      ],
    }),
  });

  if (!response.ok) {
    const text = await response.text();
    throw new Error(`GitHub Copilot API error ${response.status}: ${text.slice(0, 400)}`);
  }

  const json = await response.json();
  const content = json?.choices?.[0]?.message?.content as string | undefined;
  if (!content) {
    throw new Error(`Unexpected Copilot API response: ${JSON.stringify(json).slice(0, 300)}`);
  }
  return content.trim();
}
